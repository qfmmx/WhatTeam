<template>
  <router-view />
</template>
